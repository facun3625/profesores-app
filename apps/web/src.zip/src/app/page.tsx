"use client";

import { useEffect, useMemo, useState } from "react";
import { api } from "@/lib/api";

type Subject = { id: string; name: string };
type Topic = { id: string; name: string; subjectId: string };

type GenerateOrReuseResponse = {
  mode: "created" | "reused";
  exam: { id: string; title: string };
  exportPdfUrl: string;
};

type Difficulty = "easy" | "medium" | "hard";
type QType = "MULTIPLE_CHOICE" | "TRUE_FALSE" | "OPEN";

type Question = {
  id: string;
  type: QType;
  difficulty: Difficulty;
  statement: string;
  options?: string[] | null;
  modelAnswer?: string | null;
};

type PreviewQuestionsResponse = {
  questions: Question[];
};

type PreviewBucket = {
  type: QType;
  difficulty: Difficulty;
  count: number;
  available: number;
};

type StockPreviewResponse = {
  institutionId: string;
  topicIds: string[];
  isPossible: boolean;
  buckets: PreviewBucket[];
  shortage?: any[];
  movements?: any[];
  combinationsEstimate?: number;
};

function labelType(t: QType) {
  if (t === "MULTIPLE_CHOICE") return "Multiple choice";
  if (t === "TRUE_FALSE") return "True/False";
  return "Open";
}

export default function Page() {
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [subjectId, setSubjectId] = useState("");
  const [topics, setTopics] = useState<Topic[]>([]);
  const [topicIds, setTopicIds] = useState<string[]>([]);

  const [title, setTitle] = useState("Examen de prueba");

  const [mc, setMc] = useState(0);
  const [tf, setTf] = useState(0);
  const [op, setOp] = useState(0);

  const totalQuestions = useMemo(() => mc + tf + op, [mc, tf, op]);

  const [difficulties, setDifficulties] = useState<Difficulty[]>(["easy", "medium", "hard"]);

  const [result, setResult] = useState<GenerateOrReuseResponse | null>(null);
  const [error, setError] = useState<string>("");

  // Stock real disponible (solo se calcula cuando hay topicIds)
  const [stock, setStock] = useState<StockPreviewResponse | null>(null);

  // Preview real de preguntas (lo que querías)
  const [previewQuestions, setPreviewQuestions] = useState<Question[] | null>(null);

  // (Opcional) mostrar info de plan/cupos del mismo preview si tu backend la devuelve
  // Si tu /exams/preview SOLO devuelve questions, este queda null y no pasa nada.
  const [previewPlan, setPreviewPlan] = useState<StockPreviewResponse | null>(null);

  useEffect(() => {
    api<Subject[]>("/subjects")
      .then(setSubjects)
      .catch((e) => setError(e.message));
  }, []);

  useEffect(() => {
    if (!subjectId) {
      setTopics([]);
      setTopicIds([]);
      setStock(null);
      setPreviewQuestions(null);
      setPreviewPlan(null);
      return;
    }

    setError("");
    setResult(null);
    setPreviewQuestions(null);
    setPreviewPlan(null);
    setStock(null);

    api<Topic[]>(`/topics/subject/${subjectId}`)
      .then((data) => {
        setTopics(data);
        setTopicIds([]);
      })
      .catch((e) => setError(e.message));
  }, [subjectId]);

  function toggleDifficulty(d: Difficulty) {
    setError("");
    setResult(null);
    setPreviewQuestions(null);
    setPreviewPlan(null);

    setDifficulties((prev) =>
      prev.includes(d) ? prev.filter((x) => x !== d) : [...prev, d]
    );
  }

  function toggleTopic(id: string) {
    setError("");
    setResult(null);
    setPreviewQuestions(null);
    setPreviewPlan(null);

    setTopicIds((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));
  }

  const typeCounts = useMemo(
    () => ({
      MULTIPLE_CHOICE: mc,
      TRUE_FALSE: tf,
      OPEN: op,
    }),
    [mc, tf, op]
  );

  function validate(): string | null {
    if (!subjectId) return "Elegí una materia.";
    if (topicIds.length === 0) return "Seleccioná al menos un tema.";
    if (difficulties.length === 0) return "Seleccioná al menos una dificultad.";
    if (totalQuestions <= 0) return "Elegí al menos 1 pregunta (MC/TF/Open).";
    return null;
  }

  // ===== STOCK AUTO: SOLO cuando hay topicIds seleccionados =====
  useEffect(() => {
    if (topicIds.length === 0 || difficulties.length === 0) {
      setStock(null);
      return;
    }

    const payload = {
      title: "stock",
      totalQuestions: 1,
      topicIds,
      typeCounts: { MULTIPLE_CHOICE: 1, TRUE_FALSE: 0, OPEN: 0 },
      difficulties,
      shuffle: false,
    };

    api<StockPreviewResponse>("/exams/preview", { method: "POST", body: payload })
      .then((r) => setStock(r))
      .catch(() => {
        // No rompas la UI si el endpoint no soporta "stock mode"
        setStock(null);
      });
  }, [topicIds, difficulties]);

  const stockByType = useMemo(() => {
    if (!stock?.buckets?.length) return null;

    const types: QType[] = ["MULTIPLE_CHOICE", "TRUE_FALSE", "OPEN"];
    const diffs: Difficulty[] = ["easy", "medium", "hard"];

    return types.map((t) => {
      const buckets = stock.buckets.filter((b) => b.type === t);

      const byDiff = diffs.reduce<Record<Difficulty, number>>((acc, d) => {
        acc[d] = buckets.find((b) => b.difficulty === d)?.available ?? 0;
        return acc;
      }, { easy: 0, medium: 0, hard: 0 });

      const total = diffs.reduce((sum, d) => sum + (byDiff[d] ?? 0), 0);
      return { type: t, total, byDiff };
    });
  }, [stock]);

  async function previewRequest() {
    setError("");
    setResult(null);
    setPreviewQuestions(null);
    setPreviewPlan(null);

    const err = validate();
    if (err) {
      setError(err);
      return;
    }

    const payload = {
      title,
      totalQuestions,
      topicIds,
      typeCounts,
      difficulties,
      shuffle: true,
    };

    try {
      // 1) Intento parsear como "questions preview"
      const r = await api<PreviewResponse>("/exams/preview-questions", { method: "POST", body: payload });

      // Si viene questions => render preguntas
      if (r && Array.isArray(r.questions)) {
        setPreviewQuestions(r.questions as Question[]);
      } else {
        // Si no viene questions, capaz viene plan/buckets
        setPreviewQuestions([]);
      }

      // Si además viene plan/buckets, lo guardo para mostrar "posible/no posible"
      if (r && Array.isArray(r.buckets)) {
        setPreviewPlan(r as StockPreviewResponse);
      } else {
        setPreviewPlan(null);
      }
    } catch (e: any) {
      setError(e.message);
    }
  }

  async function generateOrReuse() {
    setError("");
    setPreviewQuestions(null);
    setPreviewPlan(null);
    setResult(null);

    const err = validate();
    if (err) {
      setError(err);
      return;
    }

    const payload = {
      title,
      totalQuestions,
      topicIds,
      typeCounts,
      difficulties,
      shuffle: true,
    };

    try {
      const r = await api<GenerateOrReuseResponse>("/exams/generate-or-reuse", {
        method: "POST",
        body: payload,
      });
      setResult(r);
    } catch (e: any) {
      setError(e.message);
    }
  }

  const pdfHref = result ? `${process.env.NEXT_PUBLIC_API_URL}${result.exportPdfUrl}` : "";

  return (
    <main style={{ padding: 24, fontFamily: "system-ui, -apple-system, Segoe UI, Roboto" }}>
      <h1 style={{ fontSize: 22, marginBottom: 12 }}>Profesores App — Front MVP</h1>

      {error ? (
        <div style={{ padding: 12, border: "1px solid", marginBottom: 12 }}>
          <b>Error:</b> {error}
        </div>
      ) : null}

      <div style={{ display: "grid", gap: 12, maxWidth: 820 }}>
        <label>
          Título
          <input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            style={{ display: "block", width: "100%", padding: 8 }}
          />
        </label>

        <label>
          Materia
          <select
            value={subjectId}
            onChange={(e) => setSubjectId(e.target.value)}
            style={{ display: "block", width: "100%", padding: 8 }}
          >
            <option value="">— Elegí una materia —</option>
            {subjects.map((s) => (
              <option key={s.id} value={s.id}>
                {s.name}
              </option>
            ))}
          </select>
        </label>

        <div>
          <div style={{ marginBottom: 6 }}>Temas</div>
          <div style={{ display: "grid", gap: 6 }}>
            {topics.map((t) => (
              <label key={t.id} style={{ display: "flex", gap: 8, alignItems: "center" }}>
                <input
                  type="checkbox"
                  checked={topicIds.includes(t.id)}
                  onChange={() => toggleTopic(t.id)}
                />
                {t.name}
              </label>
            ))}
            {subjectId && topics.length === 0 ? <i>No hay temas aún.</i> : null}
          </div>
        </div>

        {/* Stock SOLO si hay temas seleccionados */}
        {stockByType && topicIds.length > 0 ? (
          <div style={{ padding: 12, border: "1px solid" }}>
            <div style={{ fontWeight: 700, marginBottom: 8 }}>Preguntas disponibles</div>

            <div style={{ fontSize: 13, opacity: 0.9, marginBottom: 10 }}>
              {topicIds.length} tema(s) seleccionados · dificultades: {difficulties.join(", ")}
            </div>

            <div style={{ display: "grid", gap: 10 }}>
              {stockByType.map((row) => (
                <div key={row.type}>
                  <div style={{ fontWeight: 600 }}>
                    {labelType(row.type)}: {row.total}
                  </div>
                  <div style={{ fontSize: 13, opacity: 0.85 }}>
                    easy: {row.byDiff.easy} · medium: {row.byDiff.medium} · hard: {row.byDiff.hard}
                  </div>
                </div>
              ))}
            </div>
          </div>
        ) : null}

        {/* Total auto */}
        <div style={{ padding: 12, border: "1px solid" }}>
          <div style={{ fontWeight: 600 }}>Total de preguntas</div>
          <div style={{ fontSize: 18, marginTop: 6 }}>{totalQuestions}</div>
          <div style={{ fontSize: 12, opacity: 0.8 }}>(se calcula como MC + TF + Open)</div>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 12 }}>
          <label>
            Multiple choice
            <input
              type="number"
              value={mc}
              onChange={(e) => setMc(Number(e.target.value))}
              style={{ display: "block", width: "100%", padding: 8 }}
              min={0}
            />
          </label>
          <label>
            True/False
            <input
              type="number"
              value={tf}
              onChange={(e) => setTf(Number(e.target.value))}
              style={{ display: "block", width: "100%", padding: 8 }}
              min={0}
            />
          </label>
          <label>
            Open
            <input
              type="number"
              value={op}
              onChange={(e) => setOp(Number(e.target.value))}
              style={{ display: "block", width: "100%", padding: 8 }}
              min={0}
            />
          </label>
        </div>

        <div>
          <div style={{ marginBottom: 6 }}>Dificultades</div>
          <div style={{ display: "flex", gap: 12 }}>
            {(["easy", "medium", "hard"] as Difficulty[]).map((d) => (
              <label key={d} style={{ display: "flex", gap: 8, alignItems: "center" }}>
                <input
                  type="checkbox"
                  checked={difficulties.includes(d)}
                  onChange={() => toggleDifficulty(d)}
                />
                {d}
              </label>
            ))}
          </div>
        </div>

        <div style={{ display: "flex", gap: 12 }}>
          <button onClick={previewRequest} style={{ padding: "10px 14px" }}>
            Preview
          </button>
          <button onClick={generateOrReuse} style={{ padding: "10px 14px" }}>
            Generate-or-reuse
          </button>
        </div>

        {/* Preview plan (solo si el backend lo devuelve) */}
        {previewPlan ? (
          <div style={{ padding: 12, border: "1px solid" }}>
            <div style={{ fontWeight: 700, marginBottom: 8 }}>
              Preview — {previewPlan.isPossible ? "✅ Se puede generar" : "❌ No alcanza el banco"}
            </div>
            <div style={{ fontWeight: 600, marginBottom: 6 }}>Pedido vs disponible</div>
            <ul style={{ paddingLeft: 18, margin: 0, display: "grid", gap: 6 }}>
              {(previewPlan.buckets ?? []).map((b, idx) => (
                <li key={idx}>
                  {labelType(b.type)} · {b.difficulty}: <b>{b.count}</b> / {b.available}
                </li>
              ))}
            </ul>
          </div>
        ) : null}

        {/* Preview de preguntas (lo importante) */}
        {previewQuestions ? (
          <div style={{ padding: 12, border: "1px solid" }}>
            <div style={{ fontWeight: 700, marginBottom: 8 }}>
              Vista previa del examen ({previewQuestions.length})
            </div>

            {previewQuestions.length === 0 ? (
              <div style={{ opacity: 0.85 }}>
                No se recibieron preguntas en el preview. Si el backend está devolviendo “plan” y no
                “questions”, avisame y lo conectamos al endpoint correcto.
              </div>
            ) : (
              <ol style={{ display: "grid", gap: 14, paddingLeft: 18, margin: 0 }}>
                {previewQuestions.map((q) => (
                  <li key={q.id}>
                    <div style={{ fontWeight: 700, marginBottom: 6 }}>{q.statement}</div>
                    <div style={{ fontSize: 12, opacity: 0.85, marginBottom: 8 }}>
                      {labelType(q.type)} · {q.difficulty}
                    </div>

                    {q.type === "MULTIPLE_CHOICE" && q.options?.length ? (
                      <ul style={{ paddingLeft: 18, margin: 0, display: "grid", gap: 4 }}>
                        {q.options.map((opt, idx) => (
                          <li key={`${q.id}-${idx}`}>{opt}</li>
                        ))}
                      </ul>
                    ) : null}

                    {q.type === "TRUE_FALSE" && q.options?.length ? (
                      <div style={{ fontSize: 13, opacity: 0.9 }}>
                        Opciones: {q.options.join(" / ")}
                      </div>
                    ) : null}

                    {q.type === "OPEN" ? (
                      <div style={{ fontSize: 13, opacity: 0.9 }}>
                        (Respuesta en blanco — tipo desarrollo)
                      </div>
                    ) : null}
                  </li>
                ))}
              </ol>
            )}
          </div>
        ) : null}

        {result ? (
          <div style={{ padding: 12, border: "1px solid" }}>
            <div>
              <b>Mode:</b> {result.mode}
            </div>
            <div>
              <b>Exam:</b> {result.exam.title} ({result.exam.id})
            </div>
            <div style={{ marginTop: 8 }}>
              <a href={pdfHref} target="_blank" rel="noreferrer">
                Descargar PDF
              </a>
            </div>
          </div>
        ) : null}
      </div>
    </main>
  );
}
