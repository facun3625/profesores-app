const API_URL = process.env.NEXT_PUBLIC_API_URL!;
const USER_ID = process.env.NEXT_PUBLIC_USER_ID!;

type HttpMethod = "GET" | "POST" | "DELETE";

export async function api<T>(
  path: string,
  options?: { method?: HttpMethod; body?: unknown }
): Promise<T> {
  const res = await fetch(`${API_URL}${path}`, {
    method: options?.method ?? "GET",
    headers: {
      "Content-Type": "application/json",
      "x-user-id": USER_ID,
    },
    body: options?.body ? JSON.stringify(options.body) : undefined,
    cache: "no-store",
  });

  if (!res.ok) {
    const text = await res.text();
    throw new Error(`${res.status} ${res.statusText} - ${text}`);
  }

  return (await res.json()) as T;

  console.log("x-user-id =", USER_ID);

}
